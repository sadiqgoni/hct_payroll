<script src="{{url('assets/js/jquery.min.js')}}"></script>
<script src="{{url('assets/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{url('assets/js/Dynamic-Table.js')}}"></script>

