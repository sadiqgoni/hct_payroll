<?php

namespace App\Livewire\Forms;

use Livewire\Component;

class PayrollReportCenter extends Component
{
    public function render()
    {
        return view('livewire.forms.payroll-report-center')->extends('components.layouts.app');
    }
}
