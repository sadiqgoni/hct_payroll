<?php

namespace App\Livewire\Forms;

use Livewire\Component;

class LoanDeductionUpload extends Component
{
    public function render()
    {
        return view('livewire.forms.loan-deduction-upload');
    }
}
