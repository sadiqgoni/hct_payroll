<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Two-Factor Authentication Settings')); ?></div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <p>Two-factor authentication (2FA) adds an additional layer of security to your account by requiring more than just a password to log in.</p>

                        <?php if(auth()->user()->is_2fa_enabled): ?>
                            <div class="alert alert-success">
                                Two-factor authentication is currently <strong>enabled</strong> on your account.
                            </div>

                            <form method="POST" action="<?php echo e(route('2fa.disable')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">
                                    <?php echo e(__('Disable 2FA')); ?>

                                </button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                Two-factor authentication is currently <strong>disabled</strong> on your account.
                            </div>

                            <form method="POST" action="<?php echo e(route('2fa.enable')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Enable 2FA')); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/auth/2fa-settings.blade.php ENDPATH**/ ?>