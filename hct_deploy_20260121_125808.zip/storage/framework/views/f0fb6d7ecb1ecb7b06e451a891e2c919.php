<div>
    
    <div class="row">
        <div class="col-lg-12">

            <form style="padding: 10px">
               <fieldset>
                   <legend>:</legend>
                   <div wire:loading style="position: absolute;z-index: 9999;text-align: center;width: 100%;padding: 25vh;top: -50px">
                       <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
                           <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
                       </div>
                   </div>
                   <div class="row">
                       <div class="col-12 col-md-6">
                           <div class="form-group">
                               <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <strong class="text-danger"><?php echo e($message); ?></strong>
                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               <div class="input-group">
                                   <div class="input-group-prepend"><span class="input-group-text">Month</span></div>
                                   <select class="form-control <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.live="month" >
                                       <option value="">Select Month</option>
                                       <option value="January">January</option>
                                       <option value="February">February</option>
                                       <option value="March">March</option>
                                       <option value="April">April</option>
                                       <option value="May">May</option>
                                       <option value="June">June</option>
                                       <option value="July">July</option>
                                       <option value="August">August</option>
                                       <option value="September">September</option>
                                       <option value="October">October</option>
                                       <option value="November">November</option>
                                       <option value="December">December</option>
                                   </select>

                                   <div class="input-group-append"></div>
                               </div>
                           </div>
                       </div>
                       <div class="col-12 col-md-6">
                           <div class="form-group">
                               <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                               <strong class="text-danger"><?php echo e($message); ?></strong>
                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                               <div class="input-group">
                                   <div class="input-group-prepend"><span class="input-group-text">Year</span></div>
                                   <select class="form-control <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="year">
                                       <?php
                                           $firstYear = \Illuminate\Support\Carbon::now()->subYears(20)->format('Y');
                                           $lastYear = \Illuminate\Support\Carbon::now()->addYears(20)->format('Y');
                                       ?>
                                       <?php for($i=$firstYear;$i<=$lastYear;$i++): ?>
                                           <option value="<?php echo e($i); ?>" <?php if(date('Y') == $i): ?> selected <?php endif; ?>><?php echo e($i); ?></option>
                                       <?php endfor; ?>
                                   </select>
                                   <div class="input-group-append"></div>
                               </div>
                           </div>

                       </div>
                       <div class="col-12 col-md-12">
                           <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <strong class="text-danger"><?php echo e($message); ?></strong>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           <div class="input-group">
                               <div class="input-group-prepend"><span class="input-group-text">Description</span></div>
                               <input class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="description" type="text">
                               <div class="input-group-append"></div>
                           </div>
                           <small class="text-muted">Description is auto-generated based on institution name, month, and year (editable)</small>
                       </div>

                   </div>
               </fieldset>


                <button  wire:click.prevent="store()" class="btn mt-3 save_btn" type="button">Post</button>
            </form>
        </div>
    </div>

    
    <div class="row mt-4">
        <div class="col-lg-12">
            <fieldset>
                <legend><i class="fa fa-history"></i> Recently Posted Salaries</legend>
                <div wire:loading style="position: absolute;z-index: 9999;text-align: center;width: 100%;padding: 25vh;top: -50px">
                    <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
                        <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
                    </div>
                </div>
                <div class="row">
                    <?php if($recentSalaries->count() > 0): ?>
                        <?php $__currentLoopData = $recentSalaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 col-md-6 col-lg-4 mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" style="background: #007bff; color: white; border: 1px solid #007bff;">
                                            <i class="fa fa-calendar"></i>
                                        </span>
                                    </div>
                                    <div class="form-control" style="background: #f8f9fa;">
                                        <strong><?php echo e($salary->salary_month); ?> <?php echo e($salary->salary_year); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($salary->staff_count); ?> staff<?php echo e($salary->staff_count != 1 ? 's' : ''); ?></small>
                                    </div>
                                    <div class="input-group-append">
                                        <span class="input-group-text">
                                            <span class="badge badge-primary"><?php echo e($salary->staff_count); ?></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="col-12">
                            <div class="text-center text-muted py-4" style="border: 1px dashed #dee2e6; border-radius: 5px;">
                                <i class="fa fa-inbox fa-2x mb-2"></i>
                                <p class="mb-0">No salary records posted yet</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </fieldset>
        </div>
    </div>

    <?php $__env->startSection('title'); ?>
        Salary Ledger Posting
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('page_title'); ?>
        Payroll Update /  Salary  Posting
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/forms/salary-ledger-posting.blade.php ENDPATH**/ ?>