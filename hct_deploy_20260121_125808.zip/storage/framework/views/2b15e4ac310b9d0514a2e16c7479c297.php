<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bank Summary Report</title>
    <style>
        
        tfoot td, tfoot tr{
            border-collapse: collapse;
            border:0;
        }
        tfoot tr:first-child td {
            border-top: none;
        }
        tfoot tr:last-child td {
            border-top: none;
        }
        tr td{
            padding: 4px 2px;
        }
        .border-none {
            border-collapse: collapse;
            border: none;
        }
        *{
            font-family: "Times New Roman";
            font-size: 12px;
        }
        #footer { position: fixed; right: 0px; bottom: 10px; text-align: center;border-top: 1px solid black;}
        #footer .page:after { content: counter(page, decimal); }
        @page { margin: 20px 30px 40px 50px; }
    </style>
</head>
<body style="margin-left:80px;margin-right: 50px">
<img src="<?php echo e(public_path('storage/'.app_settings()->logo)); ?>" alt="" style="width: 50px;position: absolute;left: 70px">
<h3 style="padding: 0;margin: 0;text-align: center;text-transform: uppercase"><?php echo e(app_settings()->name); ?></h3>
<h4 style="padding: 0;margin: 0;text-align: center"><?php echo e(address()); ?></h4>


<h6 style="text-align: center" >Bank Payment Report for the Month of <?php echo e(\Illuminate\Support\Carbon::parse($date_from)->format('F Y')); ?></h6>







<table class="border-none" border="1" style="width: 100%; border-collapse: collapse;font-size: 12px;margin-top: 50px">
    <thead>
    <tr>
        <th>S/N</th>
        <th>ACCT <br> NUMBER</th>
        <th>AMOUNT</th>
        <th>BANK</th>
        <th>BRANCH</th>
        <th>SORT <br> CODE</th>
        <th>REMARK</th>
        <th>STAFF No</th>
        <th>IPP No</th>
        <th>STAFF <br>NAME</th>
    </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php if($report->amount > 0): ?>
            <tr>
                <td><?php echo e($index+1); ?>.</td>
                <td><?php echo e($report->account_number); ?></td>
                <td><?php echo e(number_format($report->amount,2)); ?></td>
                <td><?php echo e($report->bank); ?></td>

                <td><?php echo e($report->branch); ?></td>
                <td><?php echo e($report->sort_code); ?></td>
                <td><?php echo e($report->remark); ?></td>
                <td><?php echo e($report->staff_number); ?></td>
                <td><?php echo e($report->ipp_no); ?></td>
                <td><?php echo e($report->staff_name); ?></td>
            </tr>
        <?php endif; ?>



    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <?php endif; ?>

    </tbody>
    <tfoot>
    <tr>
        <td colspan="2"><h4 style="margin: 0">Grand Total</h4></td>
        <td colspan="7"><h4 style="margin: 0"><?php echo e(number_format($reports->sum('amount'),2)); ?></h4></td>
        
    </tr>
    <tr>
        <td colspan="5">
            <p>Authorised Signature: ............................................................................</p>
            <p>Name: ................................................................................. Thumb Print</p>
            <div style="border:1px solid black;padding: 23px;float: right;margin-top: -58px"></div>
        </td>
        <td></td>
        <td colspan="3">
            <p>Authorised Signature: .........................................................................</p>
            <p>Name: ............................................................................. Thumb Print</p>
            <div style="border:1px solid black;padding: 23px;float: right;margin-top: -58px"></div>

        </td>
    </tr>
    </tfoot>
</table>
<div id="footer">
    <p class="page">Page </p>
</div>
</body>
</html>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/reports/bank_payment_report.blade.php ENDPATH**/ ?>