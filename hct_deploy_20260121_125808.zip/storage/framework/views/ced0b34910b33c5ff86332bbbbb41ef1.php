<table>
    <thead>
    <tr>
        <th>id</th>
        <th>employment_id</th>
        <th>full_name</th>
        <th>department</th>
        <th>staff_category</th>
        <th>employment_type</th>
        <th>staff_number</th>
        <th>payroll_number</th>
        <th>status</th>
        <th>salary_structure</th>
        <th>date_of_first_appointment</th>
        <th>date_of_last_appointment</th>
        <th>date_of_retirement</th>
        <th>contract_termination_date</th>
        <th>post_held</th>
        <th>grade_level</th>
        <th>step</th>
        <th>rank</th>
        <th>unit</th>
        <th>phone_number</th>
        <th>whatsapp_number</th>
        <th>email</th>
        <th>bank_name</th>
        <th>account_number</th>
        <th>bank_code</th>
        <th>pfa_name</th>
        <th>pension_pin</th>
        <th>date_of_birth</th>
        <th>gender</th>
        <th>religion</th>
        <th>tribe</th>
        <th>marital_status</th>
        <th>nationality</th>
        <th>state_of_origin</th>
        <th>local_government</th>
        <th>profile_picture</th>
        <th>tax_id</th>
        <th>bvn</th>
        <th>staff_union</th>
        <th>name_of_next_of_kin</th>
        <th>next_of_kin_phone_number</th>
        <th>relationship</th>
        <th>address</th>

        <th>employee_id</th>
        <th>basic_salary</th>
        <?php for($i = 1; $i <= 14; $i++): ?>
            <th>A<?php echo e($i); ?></th>
        <?php endfor; ?>
        <?php for($i = 1; $i <= 50; $i++): ?>
            <th>D<?php echo e($i); ?></th>
        <?php endfor; ?>

        <th>salary_arears</th>
        <th>gross_pay</th>
        <th>total_allowance</th>
        <th>total_deduction</th>
        <th>net_pay</th>
        <th>deduction_countdown</th>
        <th>nhis</th>
        <th>employer_pension</th>
        <th>created_at</th>
        <th>updated_at</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $salary = \App\Models\SalaryUpdate::where('employee_id', $employee->id)->first();
        ?>
        <tr>
            <td><?php echo e($employee->id ?? ''); ?></td>
            <td><?php echo e($employee->employment_id ?? ''); ?></td>
            <td><?php echo e($employee->full_name ?? ''); ?></td>
            <td><?php echo e($employee->department ?? ''); ?></td>
            <td><?php echo e($employee->staff_category ?? ''); ?></td>
            <td><?php echo e($employee->employment_type ?? ''); ?></td>
            <td><?php echo e($employee->staff_number ?? ''); ?></td>
            <td><?php echo e($employee->payroll_number ?? ''); ?></td>
            <td><?php echo e($employee->status ?? ''); ?></td>
            <td><?php echo e($employee->salary_structure ?? ''); ?></td>
            <td><?php echo e($employee->date_of_first_appointment ?? ''); ?></td>
            <td><?php echo e($employee->date_of_last_appointment ?? ''); ?></td>
            <td><?php echo e($employee->date_of_retirement ?? ''); ?></td>
            <td><?php echo e($employee->contract_termination_date ?? ''); ?></td>
            <td><?php echo e($employee->post_held ?? ''); ?></td>
            <td><?php echo e($employee->grade_level ?? ''); ?></td>
            <td><?php echo e($employee->step ?? ''); ?></td>
            <td><?php echo e($employee->rank ?? ''); ?></td>
            <td><?php echo e($employee->unit ?? ''); ?></td>
            <td><?php echo e($employee->phone_number ?? ''); ?></td>
            <td><?php echo e($employee->whatsapp_number ?? ''); ?></td>
            <td><?php echo e($employee->email ?? ''); ?></td>
            <td><?php echo e($employee->bank_name ?? ''); ?></td>
            <td><?php echo e($employee->account_number ?? ''); ?></td>
            <td><?php echo e($employee->bank_code ?? ''); ?></td>
            <td><?php echo e($employee->pfa_name ?? ''); ?></td>
            <td><?php echo e($employee->pension_pin ?? ''); ?></td>
            <td><?php echo e($employee->date_of_birth ?? ''); ?></td>
            <td><?php echo e($employee->gender ?? ''); ?></td>
            <td><?php echo e($employee->religion ?? ''); ?></td>
            <td><?php echo e($employee->tribe ?? ''); ?></td>
            <td><?php echo e($employee->marital_status ?? ''); ?></td>
            <td><?php echo e($employee->nationality ?? ''); ?></td>
            <td><?php echo e($employee->state_of_origin ?? ''); ?></td>
            <td><?php echo e($employee->local_government ?? ''); ?></td>
            <td><?php echo e($employee->profile_picture ?? ''); ?></td>
            <td><?php echo e($employee->tax_id ?? ''); ?></td>
            <td><?php echo e($employee->bvn ?? ''); ?></td>
            <td><?php echo e($employee->staff_union ?? ''); ?></td>
            <td><?php echo e($employee->name_of_next_of_kin ?? ''); ?></td>
            <td><?php echo e($employee->next_of_kin_phone_number ?? ''); ?></td>
            <td><?php echo e($employee->relationship ?? ''); ?></td>
            <td><?php echo e($employee->address ?? ''); ?></td>

            <td><?php echo e(optional($salary)->employee_id ?? ''); ?></td>
            <td><?php echo e(optional($salary)->basic_salary ?? ''); ?></td>

            <?php for($i = 1; $i <= 14; $i++): ?>
                <td><?php echo e(optional($salary)->{"A$i"} ?? ''); ?></td>
            <?php endfor; ?>

            <?php for($i = 1; $i <= 50; $i++): ?>
                <td><?php echo e(optional($salary)->{"D$i"} ?? ''); ?></td>
            <?php endfor; ?>

            <td><?php echo e(optional($salary)->salary_arears ?? ''); ?></td>
            <td><?php echo e(optional($salary)->gross_pay ?? ''); ?></td>
            <td><?php echo e(optional($salary)->total_allowance ?? ''); ?></td>
            <td><?php echo e(optional($salary)->total_deduction ?? ''); ?></td>
            <td><?php echo e(optional($salary)->net_pay ?? ''); ?></td>
            <td><?php echo e(optional($salary)->deduction_countdown ?? ''); ?></td>
            <td><?php echo e(optional($salary)->nhis ?? ''); ?></td>
            <td><?php echo e(optional($salary)->employer_pension ?? ''); ?></td>
            <td><?php echo e(optional($salary)->created_at ?? ''); ?></td>
            <td><?php echo e(optional($salary)->updated_at ?? ''); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/exports/employee_profile_export.blade.php ENDPATH**/ ?>