<div>
    

    <div class="row">
        <div class="col-lg-12 p-3">
            <form action="<?php echo e(route('individual.report')); ?>" method="post" id="myForm" target="_blank">
                <div wire:loading  style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
                    <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
                        <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
                    </div>
                </div>
                <?php echo csrf_field(); ?>
            <fieldset>

                <legend >
                    <h6>Employee Selection:</h6>
                </legend>
                <div class="row">
                    <div class="col">
                        <?php $__errorArgs = ['month_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group form-group">
                            <div class="input-group-prepend"><span class="input-group-text">Month From</span></div>
                            <input type="month" class="form-control  <?php $__errorArgs = ['month_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer="month_from" name="month_from">

                            <div class="input-group-append"></div>
                        </div>
                    </div>
                    <div class="col">
                        <?php $__errorArgs = ['month_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group form-group">
                            <div class="input-group-prepend"><span class="input-group-text">Month To</span></div>
                            <input type="month" class="form-control  <?php $__errorArgs = ['month_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.defer="month_to" name="month_to">

                            <div class="input-group-append"></div>
                        </div>
                    </div>

                </div>

                <div class="row">
                    <div class="col-12 <?php if($report_type==3): ?> col-md-4 <?php else: ?> col-md-6 <?php endif; ?>">
                        <?php $__errorArgs = ['report_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group form-group">
                            <div class="input-group-prepend"><span class="input-group-text">Report Type</span></div>
                            <select class="form-control  <?php $__errorArgs = ['report_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.live="report_type" name="report_type">
                                <option value="">Report Type</option>
                                <option value="1">Payslip</option>
                                <option value="2">Bank Payment</option>
                                <option value="3">Deduction Details</option>

                            </select>
                            <div class="input-group-append"></div>
                        </div>
                    </div>
                    <?php if($report_type==3): ?>
                    <div class="col-12 <?php if($report_type==3): ?> col-md-4 <?php else: ?> <?php endif; ?>">
                        <div class="input-group form-group">
                            <div class="input-group-prepend"><span class="input-group-text">Deduction Type</span></div>
                            <select class="form-control  <?php $__errorArgs = ['deduction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.live="deduction" name="deduction">
                                <option value="">Select Deduction</option>
                               <?php $__currentLoopData = \App\Models\Deduction::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deduction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($deduction->id); ?>"><?php echo e($deduction->deduction_name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <div class="input-group-append"></div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="col-12 <?php if($report_type==3): ?> col-md-4 <?php else: ?> col-md-6 <?php endif; ?>">
                        <?php $__errorArgs = ['payroll_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="input-group form-group">
                            <div class="input-group-prepend"><span class="input-group-text">Payroll Number</span></div>
                            <input type="text" class="form-control <?php $__errorArgs = ['payroll_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="payroll_number" wire:model.defer="payroll_number" >

                            <div class="input-group-append"></div>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <div class="col-12 col-md-3">
                        <label for="">Order By</label>
                        <select type="text" class="form-control-sm" name="order_by" wire:model.defer="order_by">

                            <option value="date_month">Month</option>
                        </select>
                    </div>

                    <div class="col-12 col-md-3">
                        <label for="">Order</label>
                        <select type="text" class="form-control-sm" name="order" wire:model.defer="order">
                            <option value="Asc">Asc</option>
                            <option value="Desc">Desc</option>
                        </select>
                    </div>
                </div>

            </fieldset>
            <div class="row mt-3 ">
                <div class="col text-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('can_report')): ?>
                        <button wire:loading.attr="disabled" class="btn my-1 my-md-0  generate" type="button"  wire:click="generate()">Generate <span wire:loading><i class="fa fa-spin fa-spinner"></i></span></button>
                        <button class="btn view my-1 my-md-0" type="submit">View</button>
                    <?php endif; ?>

                </div>
            </div>

            </form>

        </div>
    </div>




    <div class="row">
        <div class="col">
            <?php if($report_type==1): ?>
                <?php if(!$payslips ==[]): ?>
                    <?php echo $__env->make('livewire.reports.includes.individual_payslip', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

            <?php endif; ?>
            <?php if($report_type==2): ?>
                    <?php if(!$banks ==[]): ?>
                        <?php echo $__env->make('livewire.reports.includes.individual_bank_payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

            <?php endif; ?>
            <?php if($report_type==3): ?>
                <?php if(!$deductions==[]): ?>
                        <?php echo $__env->make('livewire.reports.includes.individual_deduction', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php $__env->startSection('title'); ?>
       Report for Individual
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('page_title'); ?>
        Payroll Report /  for Individual
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/reports/report-for-individual.blade.php ENDPATH**/ ?>