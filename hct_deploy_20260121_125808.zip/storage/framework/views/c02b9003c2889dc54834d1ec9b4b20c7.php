<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PFA Report</title>
    <style>
        *{
            font-size: 12px !important;
            font-family: "Times New Roman";
        }
        table td{
            /*border-top:0 !important;*/
            /*border-left:0 !important;*/
            /*border-right:0 !important;*/
            padding: 3px 2px !important;
        }
        .border-none {
            border-collapse: collapse;
            border: none;
        }

        .border-none td {
            border: 1px solid black;
        }

        .border-none tr:first-child td {
            /*border-top: none;*/
        }

        .border-none tr:last-child td {
            /*border-bottom: none;*/
        }

        .border-none tr td:first-child {
            /*border-left: none;*/
        }

        .border-none tr td:last-child {
            /*border-right: none;*/
        }
        #footer { position: fixed; right: 0px; bottom: 10px; text-align: center;border-top: 1px solid black;}
        #footer .page:after { content: counter(page, decimal); }

        #header{
            position: fixed;
            top:0;
            left:0;
            width:100%;
            /*color:#CCC;*/
            /*background:#333;*/
            /*padding:20px;*/
            margin-bottom: 20px;
            height: 40px;
            border: 0 !important;
        }
        .header, .header-space,
        .footer, .footer-space {
            /*height: 80px;*/
            border: 0 !important;
        }
        th,td{
            border: 1px solid black;
        }
    </style>
</head>
<body style="padding: 0 75px">
<div id="footer">
    <p class="page">Page </p>
</div>
<div id="header">
    <img src="<?php echo e(public_path('storage/'.app_settings()->logo)); ?>" alt="" style="width: 50px;position: absolute;left: 80px">
    <h3 style="padding: 0;margin: 0;text-align: center;text-transform: uppercase"><?php echo e(app_settings()->name); ?></h3>
    <h4 style="padding: 0;margin: 0;text-align: center"><?php echo e(address()); ?></h4>

    <p style="padding: 10px;margin: 0;text-align: center">Pension Deduction Schedule for the month of <?php echo e(\Illuminate\Support\Carbon::parse($date)->format('F Y')); ?> </p>

</div>

<?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
       $pn=\App\Models\PFA::findOrFail($index);
    ?>
    <table style="width: 100%;border-collapse: collapse;font-size: 12px;">
        <thead>
        <tr style="border: 0 !important;">
            <td colspan="5" style=" border: 0 !important;">
                <div class="header-space">
                    <p style="padding: 0;margin-top: 90px !important;"><?php echo e($pn->name); ?> </p>

                </div>
            </td>
        </tr>
        <tr>
            <th>SN</th>
            <th>Payroll No. </th>
            <th>Staff Name </th>
            <th>Pension Pin</th>
            <th>Amount</th>
        </tr>
        </thead>
        <?php
            $counter=1;
$g_total=0;
        ?>
        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $deductions=\App\Models\Deduction::where('status','1')->get();
            $total=0

            ?>
            <?php if($report->D2 != 0 && $report->D2 != '00'): ?>
            <tr>
                <td><?php echo e($counter); ?></td>
                <td><?php echo e($report->ip_number); ?></td>
                <td><?php echo e($report->full_name); ?></td>
                <td><?php echo e($report->pension_pin); ?></td>
                <td>
                    
                    <?php echo e(number_format($report->D2, 2)); ?>

                </td>
            </tr>
            <?php endif; ?>
            <?php $counter++;$g_total+=$report->D2 ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>

<tr>
    <td></td>
    <td></td>
    <td></td>
    <th>Total</th>
    <th><?php echo e(number_format($g_total,2)); ?></th>
</tr>
        </tbody>


    </table>
    <?php if(!$loop->last): ?>
        <p style="page-break-before: always"></p>
    <?php endif; ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</body>
</html>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/reports/pfa.blade.php ENDPATH**/ ?>