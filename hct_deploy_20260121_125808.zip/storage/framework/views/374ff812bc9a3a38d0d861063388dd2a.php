<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bank Summary</title>
    <style>
        *{
            font-size: 12px;
            font-family: "Times New Roman";
        }
        tr td, tr th{
            border: 1px solid black;
        }
        table{
            border-collapse: collapse;
        }
    </style>
</head>
<body style="margin: 0 60px">


<img src="<?php echo e(public_path('storage/'.app_settings()->logo)); ?>" alt="" style="width: 50px;position: absolute;left: 70px">
<h3 style="padding: 0;margin: 0;text-align: center;text-transform: uppercase"><?php echo e(app_settings()->name); ?></h3>
<h4 style="padding: 0;margin: 0;text-align: center"><?php echo e(address()); ?></h4>
<h3  style="text-align: center;padding: 10px 0;margin: 0">Bank Summary Report For All Staff</h3>
<p  style="padding: 10px 0 20px 0;margin: 0">Month: <?php echo e(\Illuminate\Support\Carbon::parse($date_from)->format('F Y')); ?></p>

<table style="width: 100%">
    <thead>
    <tr>
        <th>S/N</th>
        <th>Bank Name</th>
        <th>Amount</th>
    </tr>
    </thead>
    <tbody>
    <?php
        $total=0;
$counter=1;
    ?>
    <?php $__empty_1 = true; $__currentLoopData = $reports->where('amount','>',0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <th><?php echo e($counter); ?></th>
                <td><?php echo e($report->bank_name); ?></td>
                <td><?php echo e(number_format($report->amount,2)); ?></td>
            </tr>



<?php
    $counter++
?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <?php endif; ?>
    </tbody>
    <tfoot>
    <tr>
        <td></td>
        <th style="text-align: right">Total Amount</th>
        <th style="text-align: left"><?php echo e(number_format($reports->sum('amount'),2)); ?></th>
    </tr>
    </tfoot>
</table>
<div style="margin-top: 30px">
    <p style="text-align: center">Approved By:……………………………………………………….</p>
    <p style="text-align: center">Sing & Date: ………………………………………………………..</p>
</div>
</body>
</html>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/reports/bank_summary.blade.php ENDPATH**/ ?>