<?php $__env->startSection('content'); ?>
    <?php echo $chart->container(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/reports/chart.blade.php ENDPATH**/ ?>