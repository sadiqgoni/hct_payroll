<div>
    
    <style>
        svg{
            display: none;
        }
    </style>
    <div>
        <form action="<?php echo e(route('loan.deduction.report')); ?>" method="post" id="myForm">
            <?php echo csrf_field(); ?>
            <label for="">Filter Deduction</label>
            <select name="deduction" id="" wire:model.live="deduction" class="form-control-sm">
                <option value="">Select Deduction</option>
                <?php $__currentLoopData = \App\Models\Deduction::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deduction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($deduction->id); ?>"><?php echo e($deduction->deduction_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="">Show</label>
            <select name="" id="" wire:model.live="perpage" class="form-control-sm">
                <option value=""></option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
                <option value="250">250</option>
                <option value="500">500</option>
            </select>
            <label for="">Date from</label>
            <input type="date" class="form-control-sm" wire:model.live="date_from" name="date_from">
            <label for="">Date to</label>
            <input type="date" class="form-control-sm" wire:model.live="date_to" name="date_to">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('can_export')): ?>
                <button class="btn my-1 my-md-0 export float-right " wire:click.prevent="export">Export</button>

            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('can_report')): ?>
                <button class="btn my-1 my-md-0 view float-right mr-md-3" type="submit">View Report</button>

            <?php endif; ?>
        </form>
    </div>
    <div class="table-responsive">
        <table class="table table-stripped table-bordered">
            <div wire:loading  style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
                <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
                    <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
                </div>
            </div>
            <thead>
            <tr>
                <th>S/N</th>
                <th>START <br> MONTH/YEAR</th>
                <th>STAFF NO.</th>
                <th>PAYROLL NO.</th>
                <th>DEDUCTION</th>
                <th>NO. OF <br/> INSTALMENT</th>
                <th>AMOUNT PAID</th>
                <th>PAY <br> MONTH/YEAR</th>
                <th>COUNTDOWN</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $deductions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deduction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $ded=\App\Models\LoanDeductionCountdown::find($deduction->employee_id);
                    $emp=\App\Models\EmployeeProfile::find($ded->employee_id);
                    $deduct=\App\Models\Deduction::find($ded->deduction_id);
                ?>
                <tr>
                    <td><?php echo e(($deductions->currentpage() -1 ) * $deductions->perpage() + $loop->iteration); ?></td>
                    <td><?php echo e(\Illuminate\Support\Carbon::parse($deduction->start_month)->format('F,Y')); ?></td>
                    <td><?php echo e($emp? $emp->staff_number : ''); ?></td>
                    <td><?php echo e($emp? $emp->payroll_number : ''); ?></td>
                    <td><?php echo e($deduct->deduction_name); ?></td>
                    <td><?php echo e($deduction->no_of_installment); ?></td>
                    <td><?php echo e(number_format($deduction->amount_paid,2)); ?></td>
                    <td><?php echo e(\Illuminate\Support\Carbon::parse($deduction->pay_month_year)->format('F,Y')); ?></td>
                    <td><?php echo e($deduction->ded_countdown); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                no record
            <?php endif; ?>
            </tbody>
            <tfoot>
            <tr>
                <td colspan="4"><?php echo e($deductions->render()); ?></td>
            </tr>
            </tfoot>
        </table>

    </div>
    <?php echo $__env->make('form_spin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startSection('title'); ?>
        Loan Deduction Countdown History
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('page_title'); ?>
        Payroll Report / Loan Deduction History
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/pages/loan-deduction-history.blade.php ENDPATH**/ ?>