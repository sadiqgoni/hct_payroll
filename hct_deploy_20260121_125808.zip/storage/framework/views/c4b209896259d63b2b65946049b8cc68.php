<div class="row">
    <div class="col-12 col-md-4">
        <?php $__errorArgs = ['salary_structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <div class="input-group form-group">
            <div class="input-group-prepend"><span class="input-group-text">Salary Structure</span></div>
            <select class="form-control <?php $__errorArgs = ['salary_structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="salary_structure" wire:model.live="salary_structure" >
                <option value="">Salary Structure</option>
                <?php $__currentLoopData = $salary_structures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($salary->id); ?>"><?php echo e($salary->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="input-group-append"></div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <?php $__errorArgs = ['grade_level_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php
            if (!is_null($salary_structure)){
$salObjs=\App\Models\SalaryStructureTemplate::where('salary_structure_id',$this->salary_structure)->select('grade_level')->get();

        }
        ?>
        <div class="input-group form-group">
            <div class="input-group-prepend"><span class="input-group-text">Grade Level From</span></div>
            <select  class="form-control <?php $__errorArgs = ['grade_level_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="grade_level_from" wire:model.blur="grade_level_from" type="number" >
                <option value="">Select Grade Level</option>
                <?php if($this->salary_structure != ''): ?>
                    <?php $__currentLoopData = $salObjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($obj->grade_level); ?>">Grade <?php echo e($obj->grade_level); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <div class="input-group-append"></div>
        </div>
    </div>
    <div class="col-12 col-md-4">
        <?php $__errorArgs = ['grade_level_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php
            if (!is_null($salary_structure)){
$salObjs=\App\Models\SalaryStructureTemplate::where('salary_structure_id',$this->salary_structure)->select('grade_level')->get();

        }
        ?>
        <div class="input-group form-group">
            <div class="input-group-prepend"><span class="input-group-text">Grade Level To</span></div>
            <select  class="form-control <?php $__errorArgs = ['grade_level_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="grade_level_to" wire:model.blur="grade_level_to" type="number" >
                <option value="">Select Grade Level</option>
                <?php if($this->salary_structure != ''): ?>
                    <?php $__currentLoopData = $salObjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($obj->grade_level); ?>">Grade <?php echo e($obj->grade_level); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
            <div class="input-group-append"></div>
        </div>
    </div>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/forms/ssd.blade.php ENDPATH**/ ?>