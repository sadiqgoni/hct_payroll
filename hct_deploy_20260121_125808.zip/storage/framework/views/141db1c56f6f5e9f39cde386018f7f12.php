<div class="container" style="overflow-x: hidden">
    <div class="row" style="overflow-x: hidden !important;">

        <p></p>


        <div class="col-12 mt-5">

            <div class="panel panel-default panel-table">
                <div class="panel-heading">
                    <div class="row">
                        <div class="col col-xs-6">
                            <h3 class="panel-title">Bank Payment</h3>
                        </div>

                    </div>
                </div>
                <?php if(!empty($payment_reports)): ?>
                    
                    <h6 style="text-align: right" >Month: <?php echo e(\Illuminate\Support\Carbon::parse($date_from)->format('F Y')); ?></h6>

                    





                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('can_export')): ?>

               <button class="btn export float-right" wire:click.prevent="export_bank_payment()">Export</button>
                    <?php endif; ?>
                    <table class="border-none" border="1" style="width: 100%; border-collapse: collapse;font-size: 12px">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>ACCT <br> NUMBER</th>
                            <th>AMOUNT</th>
                            <th>BANK</th>
                            <th>BRANCH</th>
                            <th>SORT <br> CODE</th>
                            <th>REMARK</th>
                            <th>STAFF No</th>
                            <th>Payroll No</th>
                            <th>STAFF <br>NAME</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $payment_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>
                                <td><?php echo e($index+1); ?>.</td>
                                <td><?php echo e($report->account_number); ?></td>
                                <td><?php echo e(number_format($report->amount,2)); ?></td>
                                <td><?php echo e($report->bank); ?></td>

                                <td><?php echo e($report->branch); ?></td>
                                <td><?php echo e($report->sort_code); ?></td>
                                <td><?php echo e($report->remark); ?></td>
                                <td><?php echo e($report->staff_number); ?></td>
                                <td><?php echo e($report->ipp_no); ?></td>
                                <td><?php echo e($report->staff_name); ?></td>
                            </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            no record
                        <?php endif; ?>

                        </tbody>
                        <tfoot>
                        <tr>
                            <td colspan="2"><h4 style="margin: 0;color: #1b1e21">Grand Total</h4></td>
                            <td colspan="7"><h4 style="margin: 0;color: #1b1e21"><?php echo e(number_format($payment_reports->sum('amount'),2)); ?></h4></td>
                            
                        </tr>














                        </tfoot>
                    </table>


               <?php endif; ?>

            </div>

        </div>
    </div>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/reports/includes/bank_payment.blade.php ENDPATH**/ ?>