@extends('components.layouts.app')
@section('content')
    {!! $chart->container() !!}
@endsection
