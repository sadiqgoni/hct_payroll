
<div wire:loading wire:target="store()" style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
    <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
        <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
    </div>
</div>

<div wire:loading  style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
    <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
        <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
    </div>
</div>

<div wire:loading wire:target="create()" style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
    <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
        <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
    </div>
</div>



