<div>
    
    <style>
        svg{
            display: none;
        }
    </style>
    <div class="row mt-3">
        <div class="col table-responsive">
            
            <div>

                    <label for="">Month-Year</label>
                    <input type="month" class="form-control-sm" name="date" wire:model.live="date">

                <label for="">Show</label>
                <select name="" wire:model.live="perpage" id="" class="form-control-sm">
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="250">250</option>
                    <option value="500">500</option>
                    <option value="1000">1000</option>
                </select>
                <select name="" id="" wire:model="orderAsc">
                    <option value="Asc">Asc</option>
                    <option value="Desc">Desc</option>
                </select>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-sm">
                    <div wire:loading  style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
                        <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
                            <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
                        </div>
                    </div>
                    <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Date</th>
                        <th>Payroll</th>
                        <th>Payslip</th>
                        <th>Bank Payment </th>
                        <th>Bank Summary</th>
                        <th>Deduction Schedule</th>
                        <th>Deduction Summary</th>
                        <th>Salary Journal</th>
                        <th>PFAs</th>
                        <th>NHIS</th>
                        <th>Emp Pension</th>
                    </tr>
                    </thead>
                    <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $payroll=\App\Models\ReportRepository::where('report_type',1)->where('date',$record->date)->first();
                        $payslip=\App\Models\ReportRepository::where('report_type',2)->where('date',$record->date)->first();
                        $bank_payment=\App\Models\ReportRepository::where('report_type',3)->where('date',$record->date)->first();
                        $deduction=\App\Models\ReportRepository::where('report_type',4)->where('date',$record->date)->first();
                        $deductionSummary=\App\Models\ReportRepository::where('report_type',5)->where('date',$record->date)->first();
                        $bankSummary=\App\Models\ReportRepository::where('report_type',6)->where('date',$record->date)->first();
                        $journal=\App\Models\ReportRepository::where('report_type',7)->where('date',$record->date)->first();
                        $pfa=\App\Models\ReportRepository::where('report_type',8)->where('date',$record->date)->first();
                        $nhis=\App\Models\ReportRepository::where('report_type',9)->where('date',$record->date)->first();
                        $pension=\App\Models\ReportRepository::where('report_type',10)->where('date',$record->date)->first();
                        ?>
                      <tr>
                          <td>1</td>
                          <td><?php echo e(\Illuminate\Support\Carbon::parse($record->date)->format('F Y')); ?></td>
                          <td style="padding: 20px !important;">

                              <!--[if BLOCK]><![endif]--><?php if($payroll): ?>
                                  <a href="<?php echo e(route('report.download',$payroll->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>

                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>

                              <!--[if BLOCK]><![endif]--><?php if($payslip): ?>
                                  <a href="<?php echo e(route('report.download',$payslip->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>


                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>

                              <!--[if BLOCK]><![endif]--><?php if($bank_payment): ?>
                                  <a href="<?php echo e(route('report.download',$bank_payment->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>

                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>

                              <!--[if BLOCK]><![endif]--><?php if($bankSummary): ?>
                                  <a href="<?php echo e(route('report.download',$bankSummary->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>


                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>

                              <!--[if BLOCK]><![endif]--><?php if($deduction): ?>
                                  <a href="<?php echo e(route('report.download',$deduction->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>


                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>

                              <!--[if BLOCK]><![endif]--><?php if($deductionSummary): ?>
                                  <a href="<?php echo e(route('report.download',$deductionSummary->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>


                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>

                              <!--[if BLOCK]><![endif]--><?php if($journal): ?>
                                  <a href="<?php echo e(route('report.download',$journal->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>

                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>

                              <!--[if BLOCK]><![endif]--><?php if($pfa): ?>
                                  <a href="<?php echo e(route('report.download',$pfa->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>

                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>
                              
                              <!--[if BLOCK]><![endif]--><?php if($nhis): ?>
                                  <a href="<?php echo e(route('report.download',$nhis->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>

                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>
                          <td>
                              
                              <!--[if BLOCK]><![endif]--><?php if($pension): ?>
                                  <a href="<?php echo e(route('report.download',$pension->id)); ?>" >
                                      <img src="<?php echo e(url('assets/img/pdf.png')); ?>" alt="" style="width: 20%">  <i class="fa fa-download"></i></a>

                              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </td>

                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        no record
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                    <tr>
                        <td colspan="6"><?php echo e($records->links()); ?></td>
                    </tr>
                </table>

            </div>
        </div>
    </div>
    <?php $__env->startSection('title'); ?>
        Report Repository
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('page_title'); ?>
        Report Repository
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/pages/report-repo.blade.php ENDPATH**/ ?>