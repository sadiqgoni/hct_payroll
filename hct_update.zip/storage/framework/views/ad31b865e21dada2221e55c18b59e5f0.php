<div>
    
    <!-- Spinner (hidden by default) -->


        <!-- Spinner -->




        <!-- Spinner -->

        <div class="row">
        <div class="col-lg-12 p-3">
            <div wire:loading  style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
                <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
                    <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
                </div>
            </div>
            <form action="<?php echo e(route('payroll_report')); ?>" method="post" id="myForm" target="_blank"><?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['date_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <strong class="text-danger"><?php echo e($message); ?></strong> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="input-group  form-group">
                            <div class="input-group-prepend"><span class="input-group-text">Report Date From</span></div>
                            <input class="form-control" type="month" name="date_from" wire:model.live="date_from">
                            <div class="input-group-append"></div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['date_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <strong class="text-danger"><?php echo e($message); ?></strong> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        <div class="input-group form-group" >
                            <div class="input-group-prepend"><span class="input-group-text">Report Date To</span></div>
                            <input class="form-control" type="month" name="date_to" wire:model.live="date_to">

                            <div class="input-group-append"></div>
                        </div>
                    </div>
                </div>
                <fieldset>
                    <legend><h6>Employee Selection:</h6></legend>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Employment Type</span></div>
                                <select class="form-control  <?php $__errorArgs = ['employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="employee_type" name="employee_type">
                                    <option value="">Employment Type</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['staff_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Staff Category</span></div>
                                <select class="form-control  <?php $__errorArgs = ['staff_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="staff_category" name="staff_category">
                                    <option value="">Staff Category</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Unit</span></div>
                                <select class="form-control <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="unit" name="unit">
                                    <option value="">Select Unit</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Department</span></div>
                                <select class="form-control <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="department" name="department">
                                    <option value="">Department</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>

                    </div>
                    <?php echo $__env->make('livewire.forms.ssd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                </fieldset>
                <fieldset class="mt-3">
                    <legend><h6>Report Type:</h6></legend>
                    <div class="row">
                        <div class="col-12 col-lg-3">
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Report Type</span></div>
                                <select class="form-control"  wire:model.live="report_type" wire:change="change" name="report_type">
                                    <option value="1" selected>Payroll</option>
                                    <option value="2">Pay Slip</option>
                                    <option value="3">Bank Payment</option>
                                    <option value="4">Deduction Schedule</option>
                                    <option value="5">Salary Deduction Summary</option>
                                    <option value="6">Bank Summary</option>
                                    <option value="7">Salary Journal</option>
                                    <option value="8">PFA Payment Schedule</option>
                                    <option value="9">NHIS </option>
                                    <option value="10">Employer Pension</option>
                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>



                        <!--[if BLOCK]><![endif]--><?php if($show_group_by == true): ?>
                            <div class="col-12 col-lg-3">
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Group By</span></div>
                                    <select class="form-control" wire:model.blur="group_by" type="text" name="group_by">
                                        
                                        <option value="department">Department</option>
                                        <option value="unit">Unit</option>
                                        <option value="employment_type">Employment Type</option>
                                        <option value="staff_category">Staff Category</option>
                                        <option value="salary_structure">Salary Structure</option>
                                        
                                    </select>
                                    <div class="input-group-append"></div>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <!--[if BLOCK]><![endif]--><?php if($show_group_by == false && $individ==true): ?>

                            <div class="col-12 col-lg-3">
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Select</span></div>
                                    <select class="form-control" wire:select.prevent="updatedGroupBy" wire:model.blur="group_by" type="text" name="group_by">
                                        
                                        <option value="">All</option>
                                        <!--[if BLOCK]><![endif]--><?php if($report_type==3 || $report_type==6): ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->bank_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($report_type==4): ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $deductions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$deduction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($deduction->id); ?>"><?php echo e($deduction->deduction_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($report_type==8): ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\PFA::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pfa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($pfa->id); ?>"><?php echo e($pfa->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <div class="input-group-append"></div>
                                </div>
                            </div>


                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="col-12 col-lg-2">
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">
                                            Order By
                                    </span>
                                    <select name="order_by" wire:model.blur="order_by" id="" class="form-control">
                                        
                                        <option value="id">Id</option>
                                        <!--[if BLOCK]><![endif]--><?php if($this->report_type==1 || $this->report_type==2 ||$this->report_type==8): ?>
                                            <!--[if BLOCK]><![endif]--><?php if($this->report_type !=4): ?>
                                            <option value="full_name" selected>Employee Name</option>
                                                <option value="pf_number">Staff Number</option>

                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($this->report_type==3): ?>
                                            <option value="bank" selected>Bank Name</option>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <!--[if BLOCK]><![endif]--><?php if($this->report_type==4): ?>
                                            <option value="staff_number" selected>Staff Number</option>
                                            <option value="staff_name" >Employee Name</option>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                    </select>
                                </div>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-2">
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">
                                            Order
                                    </span>
                                    <select name="order" wire:model.live="orderAsc" id="" class="form-control">
                                        
                                        <option value="asc">Asc</option>
                                        <option value="desc">Desc</option>
                                    </select>

                                </div>
                                <div class="input-group-append"></div>
                            </div>
                        </div>


                    </div>

                </fieldset>
                <div class="row table-bordered mt-3 ">
                    <div class="col text-center">
                        <button wire:loading.attr="disabled" class="btn generate" wire:click.prevent="generate(<?php echo e($report_type); ?>)" type="button">Generate</button>
                        <button class="btn view"  type="submit">View Pdf</button>
                    </div>
                </div>
            </form>
            <div class="row">
                <div class="col" wire:transition>
                    <!--[if BLOCK]><![endif]--><?php if($this->report_type==1): ?>
                        <?php echo $__env->make('livewire.reports.includes.payroll', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($this->report_type==2): ?>
                        <?php echo $__env->make('livewire.reports.includes.pay_slip', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($this->report_type==3): ?>
                        <?php echo $__env->make('livewire.reports.includes.bank_payment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($this->report_type==4): ?>
                        <?php echo $__env->make('livewire.reports.includes.deduction_schedule', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($this->report_type==5): ?>
                        <?php echo $__env->make('livewire.reports.includes.deduction_summary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($this->report_type==6): ?>
                        <?php echo $__env->make('livewire.reports.includes.bank_summary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($this->report_type==7): ?>
                        <?php echo $__env->make('livewire.reports.includes.journal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($this->report_type==8): ?>
                        <?php echo $__env->make('livewire.reports.includes.pfa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($this->report_type==9): ?>
                            <?php echo $__env->make('livewire.reports.includes.nhis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($this->report_type==10): ?>
                            <?php echo $__env->make('livewire.reports.includes.employer_pension', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>

        </div>
    </div>












    <?php $__env->startSection('title'); ?>
        Report Center
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('page_title'); ?>
        Payroll Report / For Group
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/reports/payroll-report-center.blade.php ENDPATH**/ ?>