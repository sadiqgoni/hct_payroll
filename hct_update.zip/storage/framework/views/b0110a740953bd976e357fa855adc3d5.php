<!--[if BLOCK]><![endif]--><?php if($record==true): ?>
<div class="row">
    <div class="col">
        <div>
            <input type="text" class="form-control-sm" wire:model.live="search" placeholder="Search for Employee..">

            <label for="">Filter By:</label>
            <select name="" id="" class="form-control-sm" wire:model.live="filter_type">
                <option value="">Employment Type</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\EmploymentType::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($emp_type->id); ?>"><?php echo e($emp_type->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <select name="" id="" class="form-control-sm" wire:model.live="filter_unit">
                <option value="">Unit</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\Unit::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($unit_filter->id); ?>"><?php echo e($unit_filter->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <select name="" id="" class="form-control-sm" wire:model.live="filter_dept">
                <option value="">Department</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $depts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>


            <label for="">Show</label>
            <select name="" id="" class="form-control-sm" wire:model.live="perpage">
                <option value="50">50</option>
                <option value="100">100</option>
                <option value="250">250</option>
                <option value="500">500</option>
                <option value="1000">1000</option>
            </select>
            <button class="btn create btn-sm float-right" wire:click.prevent="create_emp()"><i class="fa fa-plus"></i> Add Employee </button>

            

                
                
                    
                    
                
                
                

                
                
                
                
                
                


                
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-stripped">





                <thead class="thead-light">
                <tr>
                    <th>S/N</th>
                    <th>PF NUMBER</th>
                    <th>IPP NUMBER</th>
                    <th>STAFF NAME</th>
                    <th>UNIT</th>
                    <th>DEPARTMENT</th>
                    <th>ACTION</th>
                </tr>
                </thead>
                <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th><?php echo e(($employees->currentPage() - 1) * $employees->perpage() + $loop->index+1); ?></th>
                    <td><?php echo e($employee->staff_number); ?></td>
                    <td><?php echo e($employee->payroll_number); ?></td>
                    <td><?php echo e($employee->full_name); ?></td>
                    <td><?php echo e(unit_name($employee->unit)); ?></td>
                    <td><?php echo e(dept($employee->department)); ?></td>

                    <td>
                        <button class="btn btn-sm btn-info" wire:click.prevent="view_emp(<?php echo e($employee->id); ?>)">View <i class="fa fa-eye"></i></button>
                        <button class="btn btn-sm btn-danger" wire:click.prevent="deleteId(<?php echo e($employee->id); ?>)">Delete <i class="fa fa-trash-o"></i></button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
                <tfoot>
                <tr>
                    <td colspan="5"><?php echo e($employees->links()); ?></td>
                </tr>
                </tfoot>
            </table>

        </div>
    </div>
</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/forms/employee/record.blade.php ENDPATH**/ ?>