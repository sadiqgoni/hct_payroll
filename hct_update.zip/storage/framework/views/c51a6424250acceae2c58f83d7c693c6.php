<style>
    .org_name{
        color:whitesmoke;
        text-shadow:  -1px 4px  #000;
        margin-top: 0px;
        font-size:23px;
        font-weight: bolder;
        padding-left: 5%
    }
    .org_logo{
        height: 42px
    }
    @media (max-width:920px) {
        .org_name{
            color:whitesmoke;
            text-shadow:  -1px 4px  #000;
            margin-top: 0px;
            font-size:18px;
            font-weight: bolder;
            /*padding-left: 10%*/
        }
        .org_logo{
            height: unset;
            width: 68px;
            margin: 0 auto;
        }
    }
</style>
<nav style="margin-bottom: 200px !important;background:  #3d91e3" class="navbar navbar-expand-lg  fixed-top">

    <a class="navbar-brand" href="#" style="color:#000;padding:20px 47px;margin: -20px 0 -20px -15px;text-shadow: 1px 2px 1px #fff"><img src="<?php echo e(url('assets/img/hct.jpeg')); ?>" alt="" style="height: 30px">HCT PAYROLL</a>
    <button class="navbar-toggler" style="background: darkblue" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"><i class="fa fa-align-center text-white"></i></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto" style="width: 80%;padding-left: 4%">





                <img src="<?php echo e(asset('storage/'.app_settings()->logo)); ?>" alt="" style="border-radius: 50%" class="org_logo">
                <span style="" class="nav-item org_name"><?php echo e(app_settings()->name); ?></span>




        </ul>

        <?php if(auth()->guard()->check()): ?>
            <div class="div float-right mr-3">
                <li class="nav-item dropdown" style="list-style: none">
                    <a class="nav-link dropdown-toggle" href="#" style="color:white" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-cog"></i>Settings
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('can_admin')): ?>
                            <a class="dropdown-item" href="<?php echo e(route('user.account')); ?>"><i class="fa fa-user"></i> Profile</a>
                            <a class="dropdown-item" href="<?php echo e(route('change.password')); ?>"><i class="fa fa-lock"></i> Change Password</a>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('app_setting')): ?>
                                <a class="dropdown-item" href="<?php echo e(route('application.setting')); ?>"><i class="fa fa-cog"></i> App Settings</a>
                            <?php endif; ?>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"><i class="fa fa-arrow-circle-left"></i> Logout</a>

                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('can_admin')): ?>



                                <a class="dropdown-item" href="<?php echo e(route('staff.password')); ?>"><i class="fa fa-lock"></i> Change Password</a>
                                <a class="dropdown-item" href="<?php echo e(route('staff.logout')); ?>"><i class="fa fa-arrow-circle-left"></i> Logout</a>

                            <?php endif; ?>

                            <div class="dropdown-divider"></div>

                    </div>
                </li>
            </div>

        <?php endif; ?>
        <a class="nav-link text-white" href="<?php echo e(route('help.view')); ?>"><i class="fa fa-question-circle"></i> Help</a>

    </div>
</nav>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/layouts/partials/header.blade.php ENDPATH**/ ?>