<?php $__env->startSection('title'); ?>
    Tax Bracket Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>
    PAYE Tax Bracket Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="card-title mb-0" style="color: #333 !important;">Tax Brackets</h4>
                        <a href="<?php echo e(route('tax-brackets.create')); ?>" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Add New Tax Bracket
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert">
                                <span>&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php
                        $activeBracket = App\Models\TaxBracket::active()->first();
                    ?>

                    <?php if($activeBracket): ?>
                        <div class="alert alert-info">
                            <h5><i class="fas fa-info-circle"></i> Currently Active Tax Bracket</h5>
                            <strong><?php echo e($activeBracket->version_name); ?></strong> - Effective: <?php echo e($activeBracket->effective_date->format('M d, Y')); ?>

                            <br><small class="text-muted">All new payroll calculations use this bracket</small>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            <h5><i class="fas fa-exclamation-triangle"></i> No Active Tax Bracket</h5>
                            <strong>Warning:</strong> No tax bracket is currently active. The system will use default calculations.
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Version Name</th>
                                    <th>Effective Date</th>
                                    <th>Status</th>
                                    <th>Tax Brackets</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $taxBrackets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bracket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo e($bracket->version_name); ?></strong>
                                            <?php if($bracket->description): ?>
                                                <br><small class="text-muted"><?php echo e(Str::limit($bracket->description, 50)); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($bracket->effective_date->format('M d, Y')); ?></td>
                                        <td>
                                            <?php if($bracket->is_active): ?>
                                                <span class="badge badge-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($bracket->tax_brackets): ?>
                                                <?php $__currentLoopData = $bracket->tax_brackets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <small class="d-block">
                                                        ₦<?php echo e(number_format($b['min'])); ?>

                                                        <?php if(isset($b['max'])): ?>
                                                            - ₦<?php echo e(number_format($b['max'])); ?>

                                                        <?php else: ?>
                                                            & above
                                                        <?php endif; ?>
                                                        @ <?php echo e($b['rate']); ?>%
                                                    </small>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <span class="text-muted">Not configured</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($bracket->created_at->format('M d, Y')); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('tax-brackets.show', $bracket)); ?>" class="btn btn-sm btn-info" title="View Details">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('tax-brackets.edit', $bracket)); ?>" class="btn btn-sm btn-warning" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <?php if(!$bracket->is_active): ?>
                                                    <form action="<?php echo e(route('tax-brackets.activate', $bracket)); ?>" method="POST" class="d-inline"
                                                          onsubmit="return confirm('Activate this tax bracket? All future payroll calculations will use this bracket.')">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-sm btn-success" title="Activate">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    </form>
                                                    <form action="<?php echo e(route('tax-brackets.destroy', $bracket)); ?>" method="POST" class="d-inline"
                                                          onsubmit="return confirm('Delete this tax bracket?')">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">
                                            <i class="fas fa-inbox fa-2x mb-2"></i>
                                            <br>No tax brackets found.
                                            <br><a href="<?php echo e(route('tax-brackets.create')); ?>">Create your first tax bracket</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($taxBrackets->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/admin/tax-brackets/index.blade.php ENDPATH**/ ?>