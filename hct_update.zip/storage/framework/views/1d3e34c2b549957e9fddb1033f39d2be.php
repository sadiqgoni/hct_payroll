<div>
    

    <div class="row">
        <div class="col-lg-12 p-3">
            <form action="<?php echo e(route('employee.report')); ?>" method="post" id="myForm" target="_blank">
                <?php echo csrf_field(); ?>
                <div wire:loading wire:target="generate, export" style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
                    <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
                        <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
                    </div>
                </div>
                <div wire:loading  style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
                    <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
                        <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
                    </div>
                </div>
                <fieldset>
                    <legend><h6>Employee Selection:</h6></legend>
                    <div class="row">
                        <div class="col-12 col-lg-6">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Employment Type</span></div>
                                <select class="form-control  <?php $__errorArgs = ['employment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="employee_type" name="employee_type">
                                    <option value="">Employment Type</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['staff_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Staff Category</span></div>
                                <select class="form-control  <?php $__errorArgs = ['staff_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="staff_category" name="staff_category">
                                    <option value="">Staff Category</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Unit</span></div>
                                <select class="form-control <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="unit" name="unit">
                                    <option value="">Select Unit</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Department</span></div>
                                <select class="form-control <?php $__errorArgs = ['department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="department" name="department">
                                    <option value="">Department</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dept->id); ?>"><?php echo e($dept->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>

                    </div>
                   <?php echo $__env->make('livewire.forms.ssd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="row">
                        <div class="col-12 col-lg-4">
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">
                                    Order By
                            </span>
                                    <select name="order_by" wire:model.blur="order_by" id="" class="form-control">
                                        
                                        <option value="id" selected>Id</option>
                                        <option value="staff_number">Staff Number</option>
                                        <option value="full_name">Staff Name</option>
                                    </select>
                                </div>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">
                                    Order
                            </span>
                                    <select name="orderAsc" wire:model.blur="orderAsc" id="" class="form-control">
                                        
                                        <option value="asc" selected>Asc</option>
                                        <option value="desc">Desc</option>
                                    </select>
                                </div>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="input-group form-group">
                                <div class="input-group-prepend"><span class="input-group-text">Status</span></div>
                                <select class="form-control  <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.live="status">
                                    <option value="">Select Status</option>
                                    <option value="1">Active</option>
                                    <option value="2">Suspended</option>
                                    <option value="3">Dismissed</option>
                                    <option value="4">Transferred</option>
                                    <option value="5">Retired</option>
                                    <option value="6">Leave of Absence</option>
                                    <option value="7">Secondment</option>


                                </select>
                                <div class="input-group-append"></div>
                            </div>
                        </div>
                    </div>

                </fieldset>

                <fieldset class="mt-3">
                    <legend><h6>Report Layout</h6></legend>
                    <div class="row">
                        <div class="col-12 col-lg-8">
                            <h5>Choose Report Columns</h5>
                            <label for="">Staff No.</label><input type="checkbox" wire:model.live="report_column" value="1" name="report_column[]">
                            <label for="">IPP No.</label><input type="checkbox" wire:model.live="report_column" value="2" name="report_column[]">
                            <label for="">Fullname.</label><input type="checkbox" wire:model.live="report_column" value="3" name="report_column[]">
                            <label for="">Unit.</label><input type="checkbox" wire:model.live="report_column" value="4" name="report_column[]">
                            <label for="">Department.</label><input type="checkbox" wire:model.live="report_column" value="5" name="report_column[]">
                            <label for="">Phone number.</label><input type="checkbox" wire:model.live="report_column" value="6" name="report_column[]">
                            <label for="">WhatsApp No.</label><input type="checkbox" wire:model.live="report_column" value="7" name="report_column[]">
                            <label for="">Email.</label><input type="checkbox" wire:model.live="report_column" value="8" name="report_column[]">
                            <label for="">DOB.</label><input type="checkbox" wire:model.live="report_column" value="9" name="report_column[]">
                            <label for="">Salary Structure.</label><input type="checkbox" wire:model.live="report_column" value="10" name="report_column[]">
                            <label for="">Grade Level.</label><input type="checkbox" wire:model.live="report_column" value="11" name="report_column[]">
                            <label for="">Grade Step.</label><input type="checkbox" wire:model.live="report_column" value="12" name="report_column[]">
                            <label for="">DFA.</label><input type="checkbox" wire:model.live="report_column" value="13" name="report_column[]">
                            <label for="">DLA.</label><input type="checkbox" wire:model.live="report_column" value="14" name="report_column[]">
                            <label for="">Gender.</label><input type="checkbox" wire:model.live="report_column" value="15" name="report_column[]">
                            <label for="">Religion.</label><input type="checkbox" wire:model.live="report_column" value="16" name="report_column[]">
                            <label for="">Tribe.</label><input type="checkbox" wire:model.live="report_column" value="17" name="report_column[]">
                            <label for="">Marital Status.</label><input type="checkbox" wire:model.live="report_column" value="18" name="report_column[]">
                            <label for="">Nationality.</label><input type="checkbox" wire:model.live="report_column" value="19" name="report_column[]">
                            <label for="">State.</label><input type="checkbox" wire:model.live="report_column" value="20" name="report_column[]">
                            <label for="">LGA.</label><input type="checkbox" wire:model.live="report_column" value="21" name="report_column[]">
                            <label for="">Staff Cat.</label><input type="checkbox" wire:model.live="report_column" value="22" name="report_column[]">
                            <label for="">Bank.</label><input type="checkbox" wire:model.live="report_column" value="23" name="report_column[]">
                            <label for="">Account No.</label><input type="checkbox" wire:model.live="report_column" value="24" name="report_column[]">
                            <label for="">PF Name.</label><input type="checkbox" wire:model.live="report_column" value="25" name="report_column[]">
                            <label for="">Pension Pin.</label><input type="checkbox" wire:model.live="report_column" value="26" name="report_column[]">
                            <label for="">Date of Retirement.</label><input type="checkbox" wire:model.live="report_column" value="27" name="report_column[]">
                            <label for="">Contract Termination Date.</label><input type="checkbox" wire:model.live="report_column" value="28" name="report_column[]">
                            <label for="">Staff Union.</label><input type="checkbox" wire:model.live="report_column" value="29" name="report_column[]">
                            <label for="">BVN.</label><input type="checkbox" wire:model.live="report_column" value="30" name="report_column[]">
                            <label for="">Tax Id.</label><input type="checkbox" wire:model.live="report_column" value="31" name="report_column[]">
                        </div>
                        <div class="col-12 col-lg-4">
                            <div class="row">
                                <div class="col-12">
                                    <label for="">Report Title  <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['report_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <smal class="text-danger"><?php echo e($message); ?></smal><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]--></label>
                                    <input name="report_title" type="text" class="form-control <?php $__errorArgs = ['report_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="report_title" placeholder="<?php $__errorArgs = ['report_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                </div>
                                <div class="col-12">
                                    <label for="">Subtitle</label>
                                    <input name="sub_title" type="text" class="form-control <?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="sub_title" placeholder="<?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                </fieldset>

                <div class="row mt-3">
                    <div class="col text-center">

                        <button class="btn generate my-1 my-md-0" wire:click.prevent="generate()">Generate</button>
                        <button class="btn view my-1 my-md-0"  type="submit">View</button>
                        <button class="btn export my-1 my-md-0" wire:click.prevent="export()">Export</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!--[if BLOCK]><![endif]--><?php if($record=true && $report_col !=[]): ?>

        <p>Showing total number of <span class="text-primary border"><?php echo e($reports->count()); ?></span> Staffs</p>
       <div class="table-responsive">
           <table class="table table-bordered table-sm" style="font-size: 12px">

               <thead>
               <tr>
                   <th>S/N</th>
                   <!--[if BLOCK]><![endif]--><?php if(in_array(1,$report_col)): ?>
                       <th>Staff No</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(2,$report_col)): ?>
                       <th>IPP No</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(3,$report_col)): ?>
                       <th>Fullname</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(4,$report_col)): ?>
                       <th>Unit</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(5,$report_col)): ?>
                       <th>Department</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(6,$report_col)): ?>
                       <th>Phone number</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(7,$report_col)): ?>
                       <th>WhatsApp No</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(8,$report_col)): ?>
                       <th>Email</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(9,$report_col)): ?>
                       <th>DOB</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(10,$report_col)): ?>
                       <th>Salary Structure</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(11,$report_col)): ?>
                       <th>Grade Level</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(12,$report_col)): ?>
                       <th>Grade Step</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(13,$report_col)): ?>
                       <th>DFA</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(14,$report_col)): ?>
                       <th>DLA</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(15,$report_col)): ?>
                       <th>Gender</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(16,$report_col)): ?>
                       <th>Religion</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(17,$report_col)): ?>
                       <th>Tribe</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(18,$report_col)): ?>
                       <th>Marital Status</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(19,$report_col)): ?>
                       <th>Nationality</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(20,$report_col)): ?>
                       <th>State</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(21,$report_col)): ?>
                       <th>LGA</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(22,$report_col)): ?>
                       <th>Staff Cat</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(23,$report_col)): ?>
                       <th>Bank</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(24,$report_col)): ?>
                       <th>Account No</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(25,$report_col)): ?>
                       <th>PFA</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(26,$report_col)): ?>
                       <th>Pension Pin</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(27,$report_col)): ?>
                       <th>Date of Retirement</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(28,$report_col)): ?>
                       <th>Contract Termination Date</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(29,$report_col)): ?>
                           <th>Staff Union</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(30,$report_col)): ?>
                       <th>BVN</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   <!--[if BLOCK]><![endif]--><?php if(in_array(31,$report_col)): ?>
                       <th>Tax Id</th>
                   <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

               </tr>
               </thead>
               <tbody>
               <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <th><?php echo e($index+1); ?></th>
                       <!--[if BLOCK]><![endif]--><?php if(in_array(1,$report_col)): ?>
                           <td><?php echo e($report->staff_number); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(2,$report_col)): ?>
                           <td><?php echo e($report->payroll_number); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(3,$report_col)): ?>
                           <td><?php echo e($report->full_name); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(4,$report_col)): ?>
                           <td><?php echo e(unit($report->unit)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(5,$report_col)): ?>
                           <td><?php echo e(dept($report->id)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(6,$report_col)): ?>
                           <td><?php echo e($report->phone_number); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(7,$report_col)): ?>
                           <td><?php echo e($report->whatsapp_number); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(8,$report_col)): ?>
                           <td><?php echo e($report->email); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(9,$report_col)): ?>
                           <td><?php echo e($report->date_of_birth); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(10,$report_col)): ?>
                           <td><?php echo e(ss($report->salary_structure)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(11,$report_col)): ?>
                           <td><?php echo e($report->grade_level); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(12,$report_col)): ?>
                           <td><?php echo e($report->step); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(13,$report_col)): ?>
                           <td><?php echo e($report->date_of_first_appointment); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(14,$report_col)): ?>
                           <td><?php echo e($report->date_of_last_appointment); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(15,$report_col)): ?>
                           <td><?php echo e(gender($report->gender)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(16,$report_col)): ?>
                           <td><?php echo e(religion($report->religion)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(17,$report_col)): ?>
                           <td><?php echo e($report->tribe); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(18,$report_col)): ?>
                           <td><?php echo e(marital_status($report->marital_status)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(19,$report_col)): ?>
                           <td><?php echo e(nationality($report->nationality)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(20,$report_col)): ?>
                           <td><?php echo e(state($report->state_of_origin)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(21,$report_col)): ?>
                           <td><?php echo e(lga($report->local_government)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(22,$report_col)): ?>
                           <td><?php echo e($report->staff_category); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(23,$report_col)): ?>
                           <td><?php echo e($report->bank_name); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(24,$report_col)): ?>
                           <td><?php echo e($report->account_number); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(25,$report_col)): ?>
                           <td><?php echo e(pfa_name($report->pfa_name)); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(26,$report_col)): ?>
                           <td><?php echo e($report->pension_pin); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(27,$report_col)): ?>
                           <td><?php echo e($report->date_of_retirement); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(28,$report_col)): ?>
                           <td><?php echo e($report->contract_termination_date); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(29,$report_col)): ?>
                           <td><?php echo e($report->staff_union); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(30,$report_col)): ?>
                           <td><?php echo e($report->bvn); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                       <!--[if BLOCK]><![endif]--><?php if(in_array(31,$report_col)): ?>
                           <td><?php echo e($report->tax_id); ?></td>
                       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                   </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
               </tbody>
           </table>
       </div>

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->





    <?php $__env->startSection('title'); ?>
        Employee Report Center
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('page_title'); ?>
        Payroll Report / Nominal Roll
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/reports/employee-report-center.blade.php ENDPATH**/ ?>