<script src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/Dynamic-Table.js')); ?>"></script>

<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/layouts/scripts.blade.php ENDPATH**/ ?>