<div>
    
    <style>
        svg{
            display: none;
        }
        .upload-btn-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
        }

      .upload-btn-wrapper  .btn {
            border: 2px solid gray;
            color: gray;
            background-color: white;
            padding: 6px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: bold;
        }

        .upload-btn-wrapper input[type=file] {
            font-size: 100px;
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
        }
       .inport_x label {
           border: 2px solid gray;
           color: gray;
           background-color: white;
           padding: 6px 20px;
           border-radius: 8px;
           font-size: 14px;
           font-weight: bold;
        }
    </style>
    
    <div wire:loading  style="position: absolute;z-index: 9999;text-align: center;width: 100%;height: 50vh;padding: 25vh">
        <div style="background: rgba(14,13,13,0.13);margin: auto;max-width:100px;">
            <i class="fa fa-spin fa-spinner" style="font-size:100px"></i>
        </div>
    </div>
    <!--[if BLOCK]><![endif]--><?php if($record==true): ?>
        <div>
            <div class="row">
                <div class="col-12 col-md-4">




                    <a href="<?php echo e(url('assets/excel_sample/promotion.xlsx')); ?>" class="d-block text-danger">click to download sample excel file</a>
                </div>
                <div class="col-12 col-md-8">

                </div>
            </div>

            <button class="btn save_btn float-right mx-3 create" wire:click="post_to_ledger()">Post to ledger</button>
            <button class="btn create float-right" wire:click="create_record()">Add Staff</button>
            <div class="mx-3 float-right">
                <form action="" wire:submit.prevent="uploadFile()" class="inport_x">

                    <input type="file" wire:model="importFile"  id="actual-btn" hidden/>

                    <label for="actual-btn" style="z-index: 999 !important;"><!--[if BLOCK]><![endif]--><?php if($importFile): ?> <?php echo e($importFile->getClientOriginalName()); ?> <?php else: ?> Choose File <?php endif; ?><!--[if ENDBLOCK]><![endif]--></label>
                <button class="btn btn-sm btn-light" style=" border: 2px solid gray;color: gray;padding: 6px 20px;border-radius: 8px;font-size: 14px;font-weight: bold;margin-left:-10px; margin-top: -2px" type="submit">upload</button>
                </form>
                <!--[if BLOCK]><![endif]--><?php if(!empty($upload_errors)): ?>
                    <table class="table-sm table table-bordered table-striped table-warning">
                        <tr>
                            <td>Payroll Number</td>
                            <td>Error Occurred</td>
                        </tr>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $upload_errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($err[0]); ?></td>
                                <td><?php echo e($err[1]); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </table>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered mt-2">

                <thead>
                <tr style="text-transform: uppercase;">
                    <th>S/N</th>
                    <th>Payroll ID</th>
                    <th>Salary Structure </th>
                    <th>Grade Level</th>
                    <th>Step</th>
                    <th>status</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(($promotions->currentPage() - 1) * $promotions->perpage() + $loop->index+1); ?></td>
                        <td><?php echo e($promotion->payroll_number); ?></td>
                        <td><?php echo e(ss($promotion->salary_structure)); ?></td>
                        <td><?php echo e($promotion->level); ?></td>
                        <td><?php echo e($promotion->step); ?></td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($promotion->status==1): ?>
                                <span class="badge badge-success"><em>Done</em></span>
                            <?php else: ?>
                                <span class="badge badge-warning"><em>Pending</em></span>

                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <button style="width: 55px !important;padding: 1px !important;" class="btn btn-danger float-right" wire:click="deleteId(<?php echo e($promotion->id); ?>)">Delete</button>
                            <!--[if BLOCK]><![endif]--><?php if($promotion->status!=1): ?>
                            <button style="width: 55px !important;padding: 1px !important;" class="btn edit_btn float-right" wire:click="edit_record(<?php echo e($promotion->id); ?>)">Edit</button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" style="color: red">Empty</td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
                <tfoot>
                <tr style="border: 0 !important;">
                    <!--[if BLOCK]><![endif]--><?php if($promotions->count()>1): ?>
                        <td colspan="6" style="border: 0 !important;"><Button wire:click.prevent="clear_record()" class="btn btn-danger float-right">Clear Record</Button></td>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tr>
                <tr>
                    <td colspan="6"><?php echo e($promotions->links()); ?></td>
                </tr>
                </tfoot>
            </table>

            <!--[if BLOCK]><![endif]--><?php if(!empty($ledger_fails)): ?>
            <table class="table-sm table-bordered table-warning">
                <tr>
                    <th colspan="2">The following records failed to update <button wire:click="close" style="border: none;background: none;float: right;color: red;font-size: 20px">X</button></th>
                </tr>
                <tr>
                    <th>Payroll Number</th>
                    <th>Staff Name</th>
                    <th>Reason</th>
                </tr>

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ledger_fails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $emp=\App\Models\EmployeeProfile::find($ledger['id']);
                            $ss=\App\Models\SalaryStructure::find($ledger['ss'])
                        ?>
                        <tr>
                           <td><?php echo e($emp->payroll_number); ?></td>
                            <td><?php echo e($emp->full_name); ?></td>
                            <td><?php echo e($ss->name); ?> grade <?php echo e($ledger['l']); ?> is not define in salary template</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->




            </table>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($create==true): ?>
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <form wire:submit.prevent="store">
                    <fieldset>
                        <legend><h6 class="">Add Staff Promotion</h6></legend>
                        <div class="row">
                            <div class="col-12 col-md-6">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['payroll_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text"><span class="d-none d-md-inline">Payroll</span> Number</span></div>
                                    <input class="form-control <?php $__errorArgs = ['payroll_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.lazy="payroll_number" type="text">
                                    <div class="input-group-append"></div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['staff_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text"><span class="d-none d-md-inline">Staff</span> Number</span></div>
                                    <input class="form-control <?php $__errorArgs = ['staff_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.lazy="staff_number" type="text">
                                    <div class="input-group-append"></div>
                                </div>
                            </div>
                            <div class="col-12 col-md-12">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['staff_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text"><span class="d-none d-md-inline">Staff</span> Name</span></div>
                                    <input class="form-control <?php $__errorArgs = ['staff_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.lazy="staff_name" disabled readonly type="text">
                                    <div class="input-group-append"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-4">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['salary_structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Salary Structure</span></div>
                                    <select class="form-control <?php $__errorArgs = ['salary_structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="salary_structure" wire:model.blur="salary_structure" >
                                        <option value="">Salary Structure</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\SalaryStructure::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($salary->id); ?>"><?php echo e($salary->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <div class="input-group-append"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-4">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <?php
                                    if (!is_null($salary_structure)){
                        $salObj=\App\Models\SalaryStructureTemplate::where('salary_structure_id',$this->salary_structure)->select('grade_level')->get();

                                }
                                ?>
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Grade Level From</span></div>
                                    <select  class="form-control <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="level" wire:model.blur="level" type="number" >
                                        <option value="">Select Grade Level</option>
                                        <!--[if BLOCK]><![endif]--><?php if($this->salary_structure != ''): ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $salObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($obj->grade_level); ?>">Grade <?php echo e($obj->grade_level); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <div class="input-group-append"></div>
                                </div>
                            </div>


                            <div class="col-12 col-md-4">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['step'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Step</span></div>
                                    <select class="form-control <?php $__errorArgs = ['step'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="step" >
                                        <!--[if BLOCK]><![endif]--><?php if(!is_null($salObj) && !is_null($salary_structure)): ?>
                                            <?php
                                                $step_no=\App\Models\SalaryStructureTemplate::where('salary_structure_id',$salary_structure)
                                                        ->where('grade_level',$level)
                                                        ->first()
                                            ?>
                                            <option value="">Select Step</option>
                                            <!--[if BLOCK]><![endif]--><?php if(!is_null($step_no)): ?>
                                                <!--[if BLOCK]><![endif]--><?php for($i=1; $i <= $step_no->no_of_grade_steps; $i++): ?>
                                                    <option value="<?php echo e($i); ?>">Step <?php echo e($i); ?></option>
                                                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



                                    </select>
                                    <div class="input-group-append"></div>
                                </div>
                            </div>
                        </div>



                    </fieldset>

                    <div class="row mt-3">
                        <div class="col-12 col-md-8"><button class="btn save_btn" type="submit">Save</button>
                            <button class="btn close_btn mt-2 mt-md-0 " wire:click.prevent="close">Close</button></div>
                    </div>
                </form>

            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($edit==true): ?>
        <div class="row">
            <div class="col-12 col-md-10 offset-md-1">
                <form wire:submit.prevent="update(<?php echo e($ids); ?>)">
                    <fieldset>
                        <legend><h6 class="">Update Staff Promotion</h6></legend>
                        <div class="row">
                            <div class="col-12 col-md-6">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['payroll_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text"><span class="d-none d-md-inline">Payroll</span> Number</span></div>
                                    <input class="form-control <?php $__errorArgs = ['payroll_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.lazy="payroll_number" type="text">
                                    <div class="input-group-append"></div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['staff_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text"><span class="d-none d-md-inline">Staff</span> Number</span></div>
                                    <input class="form-control <?php $__errorArgs = ['staff_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.lazy="staff_number" readonly disabled type="text">
                                    <div class="input-group-append"></div>
                                </div>
                            </div>
                            <div class="col-12 col-md-12">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['staff_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text"><span class="d-none d-md-inline">Staff</span> Name</span></div>
                                    <input class="form-control <?php $__errorArgs = ['staff_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.lazy="staff_name" disabled readonly type="text">
                                    <div class="input-group-append"></div>
                                </div>
                            </div>

                            <div class="col-12 col-md-4">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['salary_structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Salary Structure</span></div>
                                    <select class="form-control <?php $__errorArgs = ['salary_structure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="salary_structure" wire:model.blur="salary_structure" >
                                        <option value="">Salary Structure</option>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = \App\Models\SalaryStructure::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($salary->id); ?>"><?php echo e($salary->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <div class="input-group-append"></div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                <?php
                                    if (!is_null($salary_structure)){
                        $salObj=\App\Models\SalaryStructureTemplate::where('salary_structure_id',$this->salary_structure)->select('grade_level')->get();

                                }
                                ?>
                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Grade Level From</span></div>
                                    <select  class="form-control <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="level" wire:model.blur="level" type="number" >
                                        <option value="">Select Grade Level</option>
                                        <!--[if BLOCK]><![endif]--><?php if($this->salary_structure != ''): ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $salObj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($obj->grade_level); ?>">Grade <?php echo e($obj->grade_level); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </select>
                                    <div class="input-group-append"></div>
                                </div>
                            </div>


                            <div class="col-12 col-md-4">
                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['step'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger d-block form-text"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                                <div class="input-group form-group">
                                    <div class="input-group-prepend"><span class="input-group-text">Step</span></div>
                                    <select class="form-control <?php $__errorArgs = ['step'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model.blur="step" >
                                        <!--[if BLOCK]><![endif]--><?php if(!is_null($salObj) && !is_null($salary_structure)): ?>
                                            <?php
                                                $step_no=\App\Models\SalaryStructureTemplate::where('salary_structure_id',$salary_structure)
                                                        ->where('grade_level',$level)
                                                        ->first()
                                            ?>
                                            <option value="">Select Step</option>
                                            <!--[if BLOCK]><![endif]--><?php if(!is_null($step_no)): ?>
                                                <!--[if BLOCK]><![endif]--><?php for($i=1; $i <= $step_no->no_of_grade_steps; $i++): ?>
                                                    <option value="<?php echo e($i); ?>">Step <?php echo e($i); ?></option>
                                                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



                                    </select>
                                    <div class="input-group-append"></div>
                                </div>
                            </div>
                        </div>



                    </fieldset>

                    <div class="row mt-3">
                        <div class="col-12 col-md-8"><button class="btn save_btn" type="submit">Update</button>
                            <button class="btn close_btn mt-2 mt-md-0 " wire:click.prevent="close">Close</button></div>
                    </div>
                </form>

            </div>
        </div>

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php $__env->startSection('title'); ?>
        Staff Promotion
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('page_title'); ?>
        Payroll Update / Staff Promotion
    <?php $__env->stopSection(); ?>
</div>
<?php /**PATH /Users/macbookpro/Downloads/hct/resources/views/livewire/forms/employee-promotion.blade.php ENDPATH**/ ?>