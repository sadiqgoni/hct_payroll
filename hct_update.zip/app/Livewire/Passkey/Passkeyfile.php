<?php

namespace App\Livewire\Passkey;

use Livewire\Component;

class Passkeyfile extends Component
{
    public function render()
    {
        return view('livewire.passkey.passkeyfile');
    }
}
