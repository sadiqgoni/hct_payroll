<footer class="text-center py-4" style="background: #3a3f48">
    <div class="mb-2">
        <small class="text-white">
            © <?php echo date('Y') ?> Powered
            by - HCT<a target="_blank" rel="noopener noreferrer" href="#">

            </a>
        </small>
    </div>
    <div>

    </div>
</footer>
