<?php

namespace App\Livewire\Reports;

use Livewire\Component;

class ExportReport extends Component
{
    public function render()
    {
        return view('livewire.reports.export-report');
    }
}
